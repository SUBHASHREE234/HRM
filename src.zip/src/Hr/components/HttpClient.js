import axios from 'axios';

const httpClient = axios.create({
   
});
export default {httpClient}
