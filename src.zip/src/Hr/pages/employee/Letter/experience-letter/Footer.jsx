import React from "react";

const Footer = () => {
  return (
    <footer className="footer-fo pt-5 footer-u">
    <div className="hr1 border-success p-1 mb-2 bg-danger">
           
           </div>
      <div>
        <div className="paragraph-1 text-u">
          Unit No. DCB-014, Dlf CyberCity, Chandaka Industrial Estate, Patia,
          Bhubaneswar -751024, Odisha
        </div>
        <div className="web-e">
          <div className="paragraph-1 email"> Email: Info@orivesolutions.com</div>
          <div className="paragraph-1 web">Website: www.orivesolutions.com</div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
