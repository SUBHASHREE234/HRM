import React from 'react';

const SalesEdit = () => {
    return (
        <div>
            
        </div>
    );
}

export default SalesEdit;
